#!/usr/bin/env python3
"""Compile-free flasher for the ambyte flash bundle, with a MAC allow-list gate.

Reads the connected board's base MAC (esptool read_mac), refuses to flash unless
that MAC is allow-listed in flash/allowed_macs.txt, then writes the prebuilt
images in bin/ with esptool. No PlatformIO project, ESP-IDF, or compiler needed.

This file is self-contained: it imports only the standard library and shells out
to esptool, so the whole flash/ folder can be handed over and run on its own.

After a successful write it provisions the board over the serial console
(USB-Serial-JTAG, same port): sets the RTC to the host's current UTC time and,
optionally, the device name — the `rtc set` / `cfg set device_name` an operator
would otherwise type by hand. Pass --no-provision to skip that step.

Usage
-----
    python flash.py                 # auto-detect port, gate, confirm, flash, provision
    python flash.py --port COM7     # explicit serial port
    python flash.py --yes           # skip the confirmation prompt
    python flash.py --any           # bypass the allow-list (flash any board)
    python flash.py --list          # print the allow-list and exit
    python flash.py --dry-run       # read MAC + gate + preview, do not write
    python flash.py --no-provision  # flash only; don't set RTC/name over the console
    python flash.py --name AMBYTE_X # set this device name (skips the name prompt)

The thin launchers flash.cmd (Windows) and flash.sh (macOS/Linux) locate a
Python interpreter and forward their arguments here.
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
BIN = HERE / "bin"
ALLOWLIST = HERE / "allowed_macs.txt"

CHIP = "esp32s3"
BAUD = "460800"
# The console REPL is a USB-Serial-JTAG CDC device, so the baud is nominal
# (USB, not a real UART) — any value works; pyserial just needs one.
CONSOLE_BAUD = 115200
CONSOLE_PROMPT = b"ambyte>"
WRITE_FLASH_ARGS = ["--flash_mode", "dio", "--flash_size", "16MB", "--flash_freq", "80m"]
# (offset, filename in bin/) — mirrors the build's flasher_args.json + nvs@0x9000.
FLASH_FILES = [
    ("0x0",     "bootloader.bin"),
    ("0x8000",  "partitions.bin"),
    ("0x9000",  "nvs.bin"),
    ("0xf000",  "ota_data_initial.bin"),
    ("0x20000", "firmware.bin"),
]

_MAC_RE = re.compile(r"([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})")
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
_PORT_RE = re.compile(r"Serial port (\S+)")


def info(m: str) -> None:
    print(m, flush=True)


def warn(m: str) -> None:
    print(f"[warn] {m}", file=sys.stderr, flush=True)


def die(m: str, code: int = 1) -> "None":
    print(f"[error] {m}", file=sys.stderr, flush=True)
    sys.exit(code)


# ── esptool resolution ─────────────────────────────────────────────────────
def _pio_core() -> Path:
    return Path(os.environ.get("PLATFORMIO_CORE_DIR") or (Path.home() / ".platformio"))


def _module_ok(python: str, mod: str) -> bool:
    try:
        return subprocess.run([python, "-c", f"import {mod}"],
                              capture_output=True).returncode == 0
    except OSError:
        return False


def _pip_install(pkg: str) -> bool:
    attempts = [[sys.executable, "-m", "pip", "install", pkg]]
    uv = shutil.which("uv")
    if uv:
        attempts.append([uv, "pip", "install", "--python", sys.executable, pkg])
    for cmd in attempts:
        try:
            if subprocess.run(cmd).returncode == 0:
                return True
        except OSError:
            continue
    return False


def resolve_esptool() -> list[str]:
    """argv prefix that runs esptool.

    Prefer PlatformIO's penv python + its bundled esptool.py (zero installs; the
    penv python already carries pyserial). Otherwise fall back to the esptool
    module in the running interpreter, installing it on first use.
    """
    core = _pio_core()
    penv_py = next((p for p in (
        core / "penv" / "Scripts" / "python.exe",
        core / "penv" / "bin" / "python",
        core / "penv" / "bin" / "python3",
    ) if p.is_file()), None)

    esptool_py = None
    pkgs = core / "packages"
    if pkgs.is_dir():
        for d in sorted(pkgs.glob("tool-esptoolpy*"), reverse=True):
            cand = d / "esptool.py"
            if cand.is_file():
                esptool_py = cand
                break

    if penv_py and esptool_py:
        return [str(penv_py), str(esptool_py)]

    if _module_ok(sys.executable, "esptool"):
        return [sys.executable, "-m", "esptool"]
    info("esptool not found - installing it...")
    if _pip_install("esptool") and _module_ok(sys.executable, "esptool"):
        return [sys.executable, "-m", "esptool"]
    die("could not find or install esptool. Install PlatformIO, or run "
        f"`{sys.executable} -m pip install esptool`, then retry.")
    return []  # unreachable


# ── allow-list ─────────────────────────────────────────────────────────────
def load_allowlist() -> set[str]:
    """Bare uppercase MACs from allowed_macs.txt (AMBYTE_ prefix + # comments OK)."""
    if not ALLOWLIST.is_file():
        return set()
    macs: set[str] = set()
    for raw in ALLOWLIST.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        m = _MAC_RE.search(line)
        if m:
            macs.add(m.group(1).upper())
    return macs


# ── board MAC + flash ──────────────────────────────────────────────────────
def _normalize_port(port: str | None) -> str | None:
    """Trim whitespace/quotes and trailing punctuation from a port name.

    esptool can print a COM port in the legacy 'COM142:' form (trailing colon);
    pyserial then builds the device path '\\\\.\\COM142:' and Windows rejects it
    with OSError 123 (ERROR_INVALID_NAME). 'COM142' opens fine. Harmless for
    POSIX names like '/dev/ttyACM0', which have no trailing punctuation."""
    if not port:
        return port
    return port.strip().strip('"').rstrip(".,;:") or None


def read_mac(esptool: list[str], port: str | None) -> tuple[str, str | None]:
    """Return (base MAC, port). The port is the caller's --port if given, else
    the one esptool auto-detected (parsed from its output) — the provisioning
    step reuses it to reach the console on the same board."""
    cmd = list(esptool) + ["--chip", CHIP]
    if port:
        cmd += ["--port", port]
    cmd += ["read_mac"]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=90,
                              env={**os.environ, "NO_COLOR": "1"})
    except subprocess.TimeoutExpired:
        die("esptool timed out reading the MAC. Close any serial monitor and retry.")
    except FileNotFoundError as exc:
        die(f"cannot launch esptool: {exc}")

    out = _ANSI_RE.sub("", (proc.stdout or "") + "\n" + (proc.stderr or ""))
    mac = None
    for line in out.splitlines():                 # prefer a MAC on a "MAC" line
        if "MAC" in line.upper():
            m = _MAC_RE.search(line)
            if m:
                mac = m.group(1).upper()
                break
    if not mac:
        m = _MAC_RE.search(out)
        mac = m.group(1).upper() if m else None
    if not mac:
        sys.stderr.write(out)
        die("esptool did not report a MAC. Is the board on USB-C and the port free "
            "(no serial monitor open)?")

    detected = port
    if not detected:
        pm = _PORT_RE.search(out)
        if pm:
            detected = pm.group(1)
    return mac, _normalize_port(detected)  # type: ignore[return-value]


def do_flash(esptool: list[str], port: str | None) -> int:
    missing = [f for _, f in FLASH_FILES if not (BIN / f).is_file()]
    if missing:
        die(f"missing image(s) in {BIN}: {', '.join(missing)} — incomplete bundle.")
    cmd = list(esptool) + ["--chip", CHIP]
    if port:
        cmd += ["--port", port]
    cmd += ["--baud", BAUD, "--before", "default_reset", "--after", "hard_reset",
            "write_flash", *WRITE_FLASH_ARGS]
    for off, fn in FLASH_FILES:
        cmd += [off, fn]
    info("  Running: " + " ".join(cmd))
    return subprocess.run(cmd, cwd=str(BIN)).returncode


# ── post-flash provisioning (RTC + device name over the console) ────────────
# A reflash rewrites nvs.bin @0x9000, wiping any custom device_name back to the
# baked-in AMBYTE_<MAC> default, and a factory-fresh board has an unset RTC. So
# after writing the images we drive the firmware's serial console (USB-Serial-
# JTAG, same USB-C port) to set the clock to host-UTC and, optionally, a name —
# exactly the `rtc set <epoch>` / `cfg set device_name <name>` an operator would
# type by hand. Best-effort: a failure here never fails the (already-done) flash.

def _utc_now() -> tuple[int, str]:
    epoch = int(time.time())
    return epoch, time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(epoch))


def _manual_hint(name: str | None) -> None:
    epoch, human = _utc_now()
    info("  Provision manually over the console instead:")
    info(f"      rtc set {epoch}          # {human}")
    info(f"      cfg set device_name {name if name else '<name>'}")
    info("      reboot")


def _find_console_port(preferred: str | None) -> str | None:
    """Reuse the port esptool used; else fall back to a lone Espressif
    USB-Serial-JTAG (VID 0x303A) on the bus."""
    preferred = _normalize_port(preferred)
    if preferred:
        return preferred
    try:
        from serial.tools import list_ports
    except Exception:
        return None
    cands = [p.device for p in list_ports.comports() if getattr(p, "vid", None) == 0x303A]
    return cands[0] if len(cands) == 1 else None


def _open_console(serial_mod, port: str, timeout_s: float = 12.0):
    """Open the port, retrying while the USB-Serial-JTAG re-enumerates after the
    post-flash hard reset."""
    deadline = time.time() + timeout_s
    last = None
    while time.time() < deadline:
        try:
            return serial_mod.Serial(port, CONSOLE_BAUD, timeout=0.2)
        except Exception as exc:  # SerialException while the port is settling
            last = exc
            time.sleep(0.5)
    if last:
        warn(f"open {port}: {last}")
    return None


def _wait_for_prompt(ser, timeout_s: float = 30.0) -> bool:
    """Nudge the REPL with newlines and watch for `ambyte>`; the boot log may
    still be streaming and interleaving with it."""
    deadline = time.time() + timeout_s
    buf = b""
    while time.time() < deadline:
        ser.write(b"\r\n")
        time.sleep(0.4)
        buf += ser.read(4096)
        if CONSOLE_PROMPT in buf:
            return True
        if len(buf) > 65536:            # keep only the recent tail
            buf = buf[-4096:]
    return False


def _send_cmd(ser, cmd: str, read_s: float = 1.5) -> str:
    ser.reset_input_buffer()            # drop pending boot-log noise
    ser.write((cmd + "\r\n").encode())
    deadline = time.time() + read_s
    out = b""
    while time.time() < deadline:
        chunk = ser.read(4096)
        if chunk:
            out += chunk
        else:
            time.sleep(0.05)
    return _ANSI_RE.sub("", out.decode(errors="replace"))


def provision(console_port: str | None, name_arg: str | None, assume_yes: bool) -> None:
    try:
        import serial  # pyserial — carried by PlatformIO's penv python
    except ImportError:
        warn("pyserial not available — skipping auto-provisioning.")
        _manual_hint(name_arg)
        return

    port = _find_console_port(console_port)
    if not port:
        warn("could not determine the console serial port — skipping auto-provisioning.")
        _manual_hint(name_arg)
        return

    info("")
    info(f"  Provisioning over the console ({port}) — waiting for boot...")
    ser = _open_console(serial, port)
    if ser is None and console_port:
        # The port esptool used didn't reopen — the USB-Serial-JTAG can come back
        # on a different COM number after the reset. Try a lone Espressif device.
        alt = _find_console_port(None)
        if alt and alt != port:
            info(f"  {port} didn't reopen; trying {alt}...")
            ser = _open_console(serial, alt)
    if ser is None:
        warn(f"could not open {port} (still busy after reset?).")
        _manual_hint(name_arg)
        return
    try:
        if not _wait_for_prompt(ser):
            warn("console prompt (ambyte>) not seen — the firmware may still be booting.")
            _manual_hint(name_arg)
            return

        # 1) RTC → host UTC now. The `rtc set <epoch>` command is UTC-based, and
        #    the firmware runs with no TZ (newlib UTC), so the host UTC epoch is
        #    exactly right and round-trips on read-back.
        epoch, human = _utc_now()
        resp = _send_cmd(ser, f"rtc set {epoch}")
        if "RTC:" in resp or "RTC set" in resp:
            line = next((l.strip() for l in reversed(resp.splitlines())
                         if l.startswith("RTC:")), "")
            info(f"  RTC set to host UTC {human}. {line}")
        else:
            warn(f"rtc set: unexpected response: {resp.strip()[:200]}")

        # 2) device name — arg wins; else prompt (unless --yes made us headless).
        name = name_arg
        if name is None and not assume_yes:
            try:
                name = input("  Device name (Enter = keep the AMBYTE_<MAC> default): ").strip()
            except EOFError:
                name = ""
        if name:
            resp = _send_cmd(ser, f"cfg set device_name {name}")
            if "cfg set device_name" in resp:
                info(f"  device_name set to '{name}' — rebooting to apply.")
                _send_cmd(ser, "reboot", read_s=1.0)
            else:
                warn(f"cfg set device_name: unexpected response: {resp.strip()[:200]}")
        else:
            info("  Keeping the default name (AMBYTE_<MAC>).")
    finally:
        ser.close()


# ── main ───────────────────────────────────────────────────────────────────
def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        description="Compile-free ambyte flasher with a MAC allow-list gate.")
    p.add_argument("--port", help="Serial port (e.g. COM7 or /dev/ttyACM0). "
                                   "Auto-detected if omitted.")
    p.add_argument("--yes", "-y", action="store_true",
                   help="Skip the confirmation prompt.")
    p.add_argument("--any", dest="any_board", action="store_true",
                   help="Bypass the allow-list and flash whatever board is connected.")
    p.add_argument("--list", action="store_true",
                   help="Print the allow-list and exit.")
    p.add_argument("--dry-run", action="store_true",
                   help="Read MAC + gate + preview, but do not write.")
    p.add_argument("--no-provision", dest="no_provision", action="store_true",
                   help="Skip the post-flash provisioning step (RTC + device name "
                        "over the console). Provisioning is ON by default.")
    p.add_argument("--name",
                   help="Device name to set after flashing (skips the prompt). "
                        "Omit to be prompted; leave the prompt blank to keep the "
                        "AMBYTE_<MAC> default.")
    args = p.parse_args(argv)
    args.port = _normalize_port(args.port)

    allow = load_allowlist()

    if args.list:
        if not allow:
            info(f"Allow-list is empty or missing ({ALLOWLIST.name}).")
        else:
            info(f"Allow-list ({len(allow)} boards) from {ALLOWLIST.name}:")
            for m in sorted(allow):
                info(f"  AMBYTE_{m}")
        return 0

    esptool = resolve_esptool()

    info("Reading board MAC (esptool)...")
    mac, console_port = read_mac(esptool, args.port)
    name = f"AMBYTE_{mac}"

    if args.any_board:
        warn(f"--any: skipping the allow-list check for {name}.")
    elif not allow:
        die(f"allow-list {ALLOWLIST.name} is empty or missing — refusing to flash. "
            f"Add {name} to it, or pass --any to override.")
    elif mac not in allow:
        die(f"{name} is NOT in the allow-list ({ALLOWLIST.name}) — refusing to flash. "
            f"Add it there, or pass --any to override.")
    else:
        info(f"  {name} is allow-listed.")

    info("")
    info(f"  Will flash prebuilt firmware + provisioning to {name}:")
    for off, fn in FLASH_FILES:
        info(f"    {off:>8}  {fn}")
    info("")

    if args.dry_run:
        info("  --dry-run: not writing.")
        return 0
    if not args.yes:
        try:
            reply = input(f"  Flash {name}? [y/N] ").strip().lower()
        except EOFError:
            reply = ""
        if reply not in ("y", "yes"):
            info("  Declined.")
            return 0

    rc = do_flash(esptool, args.port)
    if rc != 0:
        warn(f"esptool write_flash failed (exit {rc}).")
        return rc
    info(f"  OK: flashed {name}.")

    if not args.no_provision:
        provision(console_port, args.name, args.yes)
    return 0


if __name__ == "__main__":
    sys.exit(main())
